from grille import Grille
from bateau import Bateau, PorteAvion, Torpilleur, Sous_marin, Croiseur
from random import randint

##Initialisation##
g_cachée=Grille(8,10)


def vertical_ou_horizontale():
    random=randint(0,2)
    if random==0:
        return True
    return False

positions_possibles=[(i,j) for j in range(10) for i in range(8)] 
compteur=0
liste_bateaux=[PorteAvion,Croiseur,Torpilleur,Sous_marin]
liste_bateaux_posés=[]

while compteur!=4:
    coord=randint(0,len(positions_possibles))
    axe=vertical_ou_horizontale()
    bateau=liste_bateaux[compteur](positions_possibles[coord][0],positions_possibles[coord][1],axe)
    if g_cachée.peut_ajouter(bateau):
        coord_bateau=bateau.positions()
        g_cachée.ajoute(bateau,bateau.marque)
        liste_bateaux_posés.append(bateau)
        for e in coord_bateau:
            positions_possibles.remove(e)
        compteur+=1

##Gameplay##
g_visible=Grille(8,10)
print(g_visible)
coups=0
bateaux_coulés=0
while bateaux_coulés!=4:
    x_utilisateur=int(input("Veuillez renseigner une ligne entre 0 et 7 :"))
    y_utilisateur=int(input("Veuillez renseigner une colonne entre 0 et 9 :"))
    if x_utilisateur>7 or y_utilisateur>9:
        break
    g_visible.tirer(x_utilisateur,y_utilisateur)

    for b in liste_bateaux_posés:
        if (x_utilisateur,y_utilisateur) in b.positions():
            g_visible.tirer(x_utilisateur,y_utilisateur,"💣")
            g_cachée.tirer(x_utilisateur,y_utilisateur)
            if b.coulé(g_cachée,b.marque):
                g_visible.ajoute(b,b.marque)
                bateaux_coulés+=1
                print("Vous avez coulé un bateau")
    coups+=1
    print(g_visible)
print("Vous avez gagné en f{coups} coups")

    
    