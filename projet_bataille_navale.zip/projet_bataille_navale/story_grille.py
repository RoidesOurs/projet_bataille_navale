"""
Nom : "Plouf dans l'eau"
Utilisateur : un joueur
Story : On veut pouvoir gérer les tirs de l'adversaire
Actions :
créer une grille à 5 lignes et 8 colonnes
afficher la grille à l'écran
demande à l'utilisateur de rentrer deux coordonnées x et y
tirer à l'endroit indiqué sur la grille
retour en 2
"""
from grille import Grille
grille=Grille(5,8)
print(grille)
entrée_utilisateur_x=int(input("Veuillez rentrer une coordonnée x :"))
entrée_utilisateur_y=int(input("Veuillez rentrer une coordonnées y :"))
grille.tirer(entrée_utilisateur_x,entrée_utilisateur_y)
print(grille)