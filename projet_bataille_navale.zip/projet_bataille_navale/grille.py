from bateau import Bateau
vide="~"

class Grille :
    def __init__(self,nombre_lignes,nombre_colonnes):
        self.nombre_lignes=nombre_lignes
        self.nombre_colonnes=nombre_colonnes
        self.L=[vide for i in range (nombre_colonnes*nombre_lignes)]

    def tirer(self,ligne, colonne, touche="x"):
        self.L[self.nombre_colonnes*ligne+colonne]=touche
        return self.L

    def __str__(self):
        affichage=""
        for i in range(self.nombre_lignes):
            for j in range(self.nombre_colonnes):
                affichage=affichage+"  "+self.L[i*self.nombre_colonnes+j]
            affichage+="\n"
        return affichage

    def ajoute(self,bateau,marque="⛵"):
        coordonnées_bateau=bateau.positions()
        if coordonnées_bateau[0][0]<=self.nombre_lignes-1 and coordonnées_bateau[0][1]<=self.nombre_colonnes-1 and coordonnées_bateau[-1][0]<=self.nombre_lignes-1 and coordonnées_bateau[-1][1]<=self.nombre_colonnes-1 :
            for e in coordonnées_bateau:
                self.L[self.nombre_colonnes*e[0]+e[1]]=marque
        else : 
            print("le bateau ne peut pas être placé")
        return self.L

    def peut_ajouter(self,bateau):
        coordonnées_bateau=bateau.positions()
        if coordonnées_bateau[0][0]<=self.nombre_lignes-1 and coordonnées_bateau[0][1]<=self.nombre_colonnes-1 and coordonnées_bateau[-1][0]<=self.nombre_lignes-1 and coordonnées_bateau[-1][1]<=self.nombre_colonnes-1 :
            for e in coordonnées_bateau:
                if self.L[e[0]*self.nombre_colonnes+e[1]]!="~":
                    return False
            return True
        else:
            return False