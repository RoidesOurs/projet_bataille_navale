from grille import Grille
from bateau import Bateau
def test_init():
    g=Grille(1,2)
    assert isinstance(g,Grille)
    assert g.L==["~","~"]

def test_tirer():
    g=Grille(2,3)
    assert g.L==["~","~","~","~","~","~"]
    assert g.tirer(0,1)==["~","x","~","~","~","~"]

def test_str():
    g=Grille(2,3)
    assert str(g)=="  ~  ~  ~"+"\n"+"  ~  ~  ~"+"\n"

def test_ajoute():
    g=Grille(2,3)
    g.ajoute(Bateau(1, 0, longueur=2, vertical=True))
    assert g.L==["~", "~", "~", "~", "~", "~"]
    g.ajoute(Bateau(1, 0, longueur=4, vertical=True))
    assert g.L==["~", "~", "~", "~", "~", "~"]
    g.ajoute(Bateau(1, 0, longueur=2, vertical=False))
    assert g.L==["~", "~", "~", "⛵", "⛵", "~"] 
    

