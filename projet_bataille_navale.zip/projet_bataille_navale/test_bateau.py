from bateau import Bateau
from grille import Grille

def test_positions():
    assert Bateau(2, 3, 3).positions()==[(2, 3), (2, 4), (2, 5)]
    assert Bateau(2, 3, 3, True).positions()==[(2, 3), (3, 3), (4, 3)]

def test_coulé():
    g=Grille(3,4)
    b=Bateau(2,2,2)
    assert b.coulé(g)==True 
    g.ajoute(b)
    assert b.coulé(g)==False