class Bateau :
    def __init__(self,ligne,colonne,longueur=1,vertical=False):
        self.ligne=ligne
        self.colonne=colonne
        self.longueur=longueur
        self.vertical=vertical

    def positions(self):
        L=[]
        if self.vertical:
            for i in range(self.longueur):
                L.append((self.ligne+i,self.colonne))
        else :
            for i in range(self.longueur):
                L.append((self.ligne,self.colonne+i))
        return L

    def coulé(self,grille,marque="⛵"):
        coordonées_bateau=self.positions()
        for e in coordonées_bateau:
            if grille.L[e[0]*grille.nombre_colonnes+e[1]]==marque:
                return False
        return True

class PorteAvion(Bateau):
    marque="🚢"
    def __init__(self, ligne, colonne, vertical=False):
        super().__init__(ligne, colonne, 4, vertical)

class Croiseur(Bateau):
    marque="⛴"
    def __init__(self, ligne, colonne, vertical=False):
        super().__init__(ligne, colonne, 3, vertical)

class Torpilleur(Bateau):
    marque="🚣"
    def __init__(self, ligne, colonne, vertical=False):
        super().__init__(ligne, colonne, 2, vertical)

class Sous_marin(Bateau):
    marque="🐟"
    def __init__(self, ligne, colonne, vertical=False):
        super().__init__(ligne, colonne, 2, vertical)