"""
Nom : "chevauchement"
Utilisateur : un joueur
Story : Positionner des bateaux sans chevauchement
Actions :
créer un bateau b1
créer un bateau b2
Vérifier si les deux bateaux se chevauchent
"""

from bateau import Bateau

b1=Bateau(2,1,5)
b2=Bateau(1,3,4,True)

for e in b1.positions():
    if e in b2.positions():
        print("il y a cheuvauchement")

b3=Bateau(2,1,5)
b4=Bateau(1,3,4)
for e in b3.positions():
    if e in b4.positions():
        print("il y a cheuvauchement")